from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
r=Path('/task');o=r/'results';o.mkdir(exist_ok=True);binary=Path('/submission/maintainer-contract/zig-out/bin/tf-cuda-test');meta=json.loads(Path('/submission/maintainer-followup/contract-build.json').read_text());assert meta['exit_code']==0 and hashlib.sha256(binary.read_bytes()).hexdigest()==meta['binary_sha256'];attempt=str(int(time.time()));log=o/(attempt+'.log');peak=0;start=time.time()
with log.open('w')as f:
 p=subprocess.Popen([str(binary),'kernel-contract'],stdout=f,stderr=subprocess.STDOUT)
 while p.poll()is None:
  try:
   rows=Path(f'/proc/{p.pid}/status').read_text().splitlines();peak=max(peak,next((int(x.split()[1])*1024 for x in rows if x.startswith('VmHWM:')),0))
  except FileNotFoundError:pass
  (o/'progress.json').write_text(json.dumps({'attempt':attempt,'elapsed_s':time.time()-start,'peak_process_rss_bytes':peak,'pid':p.pid,'started_epoch':start},indent=2)+'\n');time.sleep(2)
 summaries=[x for x in log.read_text().splitlines()if x.startswith('SUMMARY')]
 state={'complete':p.returncode==0 and bool(summaries),'exit_code':p.returncode,'summary':summaries,'attempt':attempt,'log':log.name,'elapsed_s':time.time()-start,'peak_process_rss_bytes':peak,'build':meta,'ended_utc':datetime.now(timezone.utc).isoformat(),'scope':meta['scope']};(o/'state.json').write_text(json.dumps(state,indent=2)+'\n')
raise SystemExit(0 if state['complete']else 1)
