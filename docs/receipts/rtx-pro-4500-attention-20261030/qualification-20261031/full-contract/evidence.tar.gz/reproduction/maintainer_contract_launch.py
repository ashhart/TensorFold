from pathlib import Path
import importlib.util,json,subprocess,time,urllib.request
r=Path(__file__).resolve().parent;s=r.parent/'submission/maintainer-followup';o=r/'maintainer-contract-results';o.mkdir(exist_ok=True);prior=o/'command.json';end=json.loads(prior.read_text())['absolute_deadline']if prior.exists()else time.time()+10800
spec=importlib.util.spec_from_file_location('reserve','/shared-cache');reserve=importlib.util.module_from_spec(spec);spec.loader.exec_module(reserve)
def profile_now():
 for attempt in range(3):
  try:return reserve.policy()
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired):
   if attempt==2:raise
   time.sleep(.1)

while not(s/'contract-build.json').exists()or subprocess.run(['systemctl','--user','is-active','--quiet','tf4500-maintainer-contract-build.service']).returncode==0:
 if time.time()>end-600:raise SystemExit('Contract build budget exhausted')
 time.sleep(3)
assert json.loads((s/'contract-build.json').read_text())['exit_code']==0
while time.time()<end-600:
 try:ok=json.load(urllib.request.urlopen('http://127.0.0.1:19092/resources',timeout=5))['can_request_background']
 except OSError:ok=False
 if not ok:time.sleep(5);continue
 before=profile_now();assert before['reserve_gib']==0,'Stop on changed hardware profile'
 cmd=json.loads((r/'overnight-latest-command.json').read_text())['command'];cmd[cmd.index('--timeout')+1]=str(min(7200,int(end-time.time())-10));cmd[cmd.index(str(r/'overnight-latest-results')+':/task/results')]=str(o)+':/task/results';cmd[-1]='/task/maintainer_contract_worker.py';(o/'command.json').write_text(json.dumps({'command':cmd,'profile':before,'absolute_deadline':end},indent=2)+'\n')
 with(o/'guard.log').open('a')as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT);changed=False
  try:
   while p.poll()is None:
    now=profile_now()
    if any(now[k]!=before[k]for k in['compute_mode','graphical_desktop','reserve_gib']):changed=True;p.terminate();break
    time.sleep(3)
   code=p.wait(timeout=30)
  finally:
   if p.poll()is None:p.terminate();p.wait(timeout=30)
 (o/'exit.json').write_text(json.dumps({'exit_code':code,'profile_changed':changed},indent=2)+'\n')
 if code==75 and not changed:time.sleep(5);continue
 raise SystemExit(code)
raise SystemExit('Contract admission budget exhausted')
