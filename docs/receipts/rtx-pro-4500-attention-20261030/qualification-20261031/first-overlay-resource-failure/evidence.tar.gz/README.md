# First common lifetime overlay: still resource-limited

All three comparison binaries compiled. The MLP binary ran alone, with a common two-file gates/Rig cleanup overlay and all original kernel math, seeds, shapes, references, controls and limits unchanged. It reached the final Flash Next standalone suite but was killed after 6,005.3 seconds without a SUMMARY. Sampled peak process RSS was 25,683,369,984 bytes. The exact owned-process kernel record confirms a cgroup OOM kill at the 24 GiB cap. The earlier zero-OOM/zero-swap checkpoint predates that kill.

Stock/attention were not repeated unchanged after that failure. None is counted as a full pass. Source-and-binaries.json identifies the three built binaries, base HEADs and changed/untracked source hashes. Source-snapshots/ contains those exact changed/untracked files; apply them to their identified source HEAD. Original unmodified failures remain separately retained.

A separate latest-main local harness candidate now also scopes registered fixture/module teardown before standalone suites. That extension is absent from these binaries and is not qualified by this attempt. The existing inference PRs remain drafts with their full-suite gate outstanding. Receipt copies normalize private paths and trailing blank lines.
